# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['colornet']

package_data = \
{'': ['*']}

install_requires = \
['fastai==2.4',
 'jupyter>=1.0.0,<2.0.0',
 'jupyterlab>=3.4.4,<4.0.0',
 'matplotlib>=3.5.2,<4.0.0',
 'scikit-image>=0.19.3,<0.20.0',
 'torch==1.9.1',
 'torchvision==0.10.1',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'colornet',
    'version': '0.0.1',
    'description': '',
    'long_description': None,
    'author': 'Orest Malinovskyi',
    'author_email': 'orest0206@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
